USE AziendaTrasporti;

-- OP 1
INSERT INTO Validazione (IdTitoloViaggio, IdCorsaEffettiva, Data)
VALUES (20, 17, NOW());

-- OP 2
INSERT INTO TitoloViaggio (IdUtente, IdTariffa, Tipo, DataEmissione, DataScadenza)
VALUES (10, 3, 'Biglietto', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 DAY));

-- OP 4
INSERT INTO CorsaEffettiva (IdCorsaPianificata, IdAutista, NumeroPasseggeri, IdMezzo, Data, OraPartenzaReale, OraArrivoReale)
VALUES (5, 4, 0, 2, CURDATE(), '14:05:00', '15:00:00');

-- OP 7
INSERT INTO Reclamo (IdCorsaEffettiva, IdUtente, Testo, Data)
VALUES (1, 12, 'L''autobus ha saltato la mia fermata nonostante avessi prenotato la discesa.', CURDATE());

-- OP 3
SELECT OraPartenza AS OrariPartenzaCapolinea
FROM CorsaPianificata
WHERE IdLinea = 1
ORDER BY OraPartenza ASC;

-- OP 5
SELECT 
    PL.Progressivo, 
    F.Nome AS NomeFermata, 
    Z.Nome AS ZonaTariffaria
FROM PercorsoLinea PL
JOIN Fermata F ON PL.IdFermata = F.Id
JOIN Zona Z ON F.IdZona = Z.Id
WHERE PL.IdLinea = 2
ORDER BY PL.Progressivo ASC;

-- OP 6
SELECT 
    CE.Id AS IdCorsaEffettiva, 
    L.NomeDescrittivo AS Linea,
    CE.Data, 
    CE.OraPartenzaReale, 
    CE.NumeroPasseggeri AS AffollamentoTotale
FROM CorsaEffettiva CE
JOIN CorsaPianificata CP ON CE.IdCorsaPianificata = CP.Id
JOIN Linea L ON CP.IdLinea = L.Id
ORDER BY CE.Data DESC, CE.NumeroPasseggeri DESC;

-- OP 8
CALL ReportRitardiMensili(5, 2024);




