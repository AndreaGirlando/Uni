
-- Categoria
INSERT INTO Categoria (IdCategoria, Nome, Descrizione) VALUES
(1, 'Latticini', 'Latte, formaggi e derivati'),
(2, 'Pasta e Riso', 'Pasta secca, fresca e riso');

-- Marchio
INSERT INTO Marchio (IdMarchio, Nome) VALUES
(1, 'Parmalat'),
(2, 'Barilla');

-- Promozione
INSERT INTO Promozione (IdPromo, Titolo, Descrizione, DataInizio, DataFine) VALUES
(1, 'Sconto Estivo', 'Sconto del 10% sui freschi', '2026-06-01', '2026-08-31'),
(2, 'Svuota Dispensa', 'Prezzi tagliati sulla pasta', '2026-07-01', '2026-07-15');

-- Allergeno
INSERT INTO Allergeno (IdAllergeno, Nome, Descrizione) VALUES
(1, 'Lattosio', 'Presente nel latte e derivati'),
(2, 'Glutine', 'Presente nel grano e cereali');

-- PreferenzaAlimentare
INSERT INTO PreferenzaAlimentare (IdPreferenza, Nome, Descrizione) VALUES
(1, 'Vegetariano', 'Senza carne o pesce'),
(2, 'Senza Glutine', 'Adatto a celiaci');

-- Ricetta
INSERT INTO Ricetta (IdRicetta, Nome, Descrizione) VALUES
(1, 'Pasta Bianca Semplice', 'Ricetta veloce per un pasto leggero');

-- Corriere
INSERT INTO Corriere (IdCorriere, Nome, Cellulare, Capacita) VALUES
(1, 'Mario Rossi', '3331234567', 50),
(2, 'Luigi Bianchi', '3339876543', 30);

-- Indirizzo
INSERT INTO Indirizzo (IdIndirizzo, Via, Numero, Citta, Cap) VALUES
(1, 'Via Roma', '10', 'Milano', '20100'),
(2, 'Via Garibaldi', '25', 'Torino', '10100');

-- Cliente
INSERT INTO Cliente (IdCliente, Nome, Email, Cellulare) VALUES
(1, 'Giulia Neri', 'giulia.neri@email.it', '3401122334'),
(2, 'Marco Verdi', 'marco.verdi@email.it', '3204455667'); 

-- CartaFedelta
INSERT INTO CartaFedelta (IdCarta, Punti, DataAttivazione, Livello, IdCliente) VALUES
(1, 150, '2025-05-10', 'Silver', 1),
(2, 450, '2024-11-20', 'Gold', 2);

-- Zona
INSERT INTO Zona (IdZona, Nome, Descrizione, IdCorriere) VALUES
(1, 'Milano Centro', 'CAP 20100 e limitrofi', 1),
(2, 'Torino Nord', 'Zona nord e prima cintura', 2);

-- Prodotto (1 = Latte, 2 = Pasta)
INSERT INTO Prodotto (IdProdotto, Prezzo, Giacenza, IsFresco, IdCategoria, IdMarchio, IdPromo) VALUES
(1, 1.50, 100, TRUE, 1, 1, 1),
(2, 0.90, 500, FALSE, 2, 2, NULL);

-- ListaSalvata
INSERT INTO ListaSalvata (IdLista, Nome, DataCreazione, IdCliente) VALUES
(1, 'Spesa Settimanale', '2026-07-06', 1);

-- Ordine (Rispettando constraint DataConsegna >= DataCreazione)
INSERT INTO Ordine (IdOrdine, PrezzoTotale, DataCreazione, Stato, Tipo, DataConsegna, FasciaOraria, IdCliente, IdIndirizzo, IdCorriere) VALUES
(1, 2.40, '2026-07-06 09:00:00', 'In Preparazione', 'Consegna a domicilio', '2026-07-07 18:00:00', '18:00 - 20:00', 1, 1, 1);

-- BorsaTermica (Assegnata all'ordine per contenere il prodotto fresco)
INSERT INTO BorsaTermica (IdBorsa, Capacita, Stato, IdOrdine) VALUES
(1, 15, 'Assegnata', 1);

-- ProdottoAllergeno (Latte -> Lattosio, Pasta -> Glutine)
INSERT INTO ProdottoAllergeno (IdProdotto, IdAllergeno) VALUES
(1, 1),
(2, 2);

-- RicettaProdotto (La ricetta usa la pasta)
INSERT INTO RicettaProdotto (IdRicetta, IdProdotto, Quantita, UnitaMisura) VALUES
(1, 2, 100, 'grammi');

-- ClientePreferenza (Marco Verdi è vegetariano)
INSERT INTO ClientePreferenza (IdCliente, IdPreferenza) VALUES
(2, 1);

-- ClienteIndirizzo (Collegamento cliente-indirizzo)
INSERT INTO ClienteIndirizzo (IdCliente, IdIndirizzo) VALUES
(1, 1),
(2, 2);

-- ListaProdotto (La lista di Giulia contiene Latte e Pasta)
INSERT INTO ListaProdotto (IdLista, IdProdotto, Quantita) VALUES
(1, 1, 2),
(1, 2, 5);

-- OrdineProdotto (Congelamento dei prezzi al momento dell'acquisto)
INSERT INTO OrdineProdotto (IdOrdine, IdProdotto, Quantita, PrezzoAcquisto, IdSostituto, DataAggiunta) VALUES
(1, 1, 1, 1.50, NULL, '2026-07-06 08:55:00'),
(1, 2, 1, 0.90, NULL, '2026-07-06 08:58:00');
