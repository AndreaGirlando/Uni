
DELIMITER //
-- TRIGGER 1: Aggiornamento automatico della giacenza a magazzino
-- Quando un prodotto viene aggiunto a un ordine, la sua giacenza diminuisce.
CREATE TRIGGER TRG_ScaricoMagazzino
AFTER INSERT ON OrdineProdotto
FOR EACH ROW
BEGIN
    UPDATE Prodotto
    SET Giacenza = Giacenza - NEW.Quantita
    WHERE IdProdotto = NEW.IdProdotto;
END //

-- TRIGGER 2: Aggiornamento automatico del Prezzo Totale dell'Ordine (Dato Ridondante)
-- Implementa la logica discussa nella Sezione 3.1 della relazione.
CREATE TRIGGER TRG_AggiornaTotaleOrdine
AFTER INSERT ON OrdineProdotto
FOR EACH ROW
BEGIN
    UPDATE Ordine
    SET PrezzoTotale = PrezzoTotale + (NEW.Quantita * NEW.PrezzoAcquisto)
    WHERE IdOrdine = NEW.IdOrdine;
END //

-- TRIGGER 3: Blocco inserimento in caso di giacenza insufficiente
-- Previene l'inserimento in OrdineProdotto se la quantità richiesta supera la giacenza.
CREATE TRIGGER TRG_ControlloGiacenza
BEFORE INSERT ON OrdineProdotto
FOR EACH ROW
BEGIN
    DECLARE giacenza_attuale INT;
    
    SELECT Giacenza INTO giacenza_attuale
    FROM Prodotto
    WHERE IdProdotto = NEW.IdProdotto;
    
    IF NEW.Quantita > giacenza_attuale THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Errore: Quantità richiesta superiore alla giacenza disponibile.';
    END IF;
END //


-- 2. STORED PROCEDURE PER OPERAZIONI (O1 - O8)

-- OPERAZIONE O1: Inserimento di un nuovo ordine (Testata)
-- Crea l'ordine con totale iniziale a 0 (verrà aggiornato dal TRG_AggiornaTotaleOrdine)
CREATE PROCEDURE SP_CreaNuovoOrdine(
    IN p_IdOrdine INT,
    IN p_Tipo VARCHAR(50),
    IN p_DataConsegna DATETIME,
    IN p_FasciaOraria VARCHAR(50),
    IN p_IdCliente INT,
    IN p_IdIndirizzo INT,
    IN p_IdCorriere INT
)
BEGIN
    INSERT INTO Ordine (
        IdOrdine, PrezzoTotale, DataCreazione, Stato, Tipo, 
        DataConsegna, FasciaOraria, IdCliente, IdIndirizzo, IdCorriere
    ) VALUES (
        p_IdOrdine, 0.00, NOW(), 'In elaborazione', p_Tipo, 
        p_DataConsegna, p_FasciaOraria, p_IdCliente, p_IdIndirizzo, p_IdCorriere
    );
END //

-- OPERAZIONE O4: Estrazione prodotti da una Lista Salvata
CREATE PROCEDURE SP_EstraiListaSpesa(
    IN p_IdLista INT
)
BEGIN
    SELECT 
        P.IdProdotto, 
        P.Prezzo, 
        C.Nome AS Categoria, 
        M.Nome AS Marchio, 
        LP.Quantita
    FROM ListaProdotto LP
    JOIN Prodotto P ON LP.IdProdotto = P.IdProdotto
    JOIN Categoria C ON P.IdCategoria = C.IdCategoria
    JOIN Marchio M ON P.IdMarchio = M.IdMarchio
    WHERE LP.IdLista = p_IdLista;
END //

-- OPERAZIONE O6: Calcolo statistico ordini per Zona e Mese
CREATE PROCEDURE SP_StatisticheZonaMese(
    IN p_IdZona INT,
    IN p_Mese INT,
    IN p_Anno INT
)
BEGIN
    SELECT 
        Z.Nome AS NomeZona,
        COUNT(O.IdOrdine) AS TotaleOrdini,
        SUM(O.PrezzoTotale) AS FatturatoTotale
    FROM Ordine O
    JOIN Indirizzo I ON O.IdIndirizzo = I.IdIndirizzo
    JOIN Corriere C ON O.IdCorriere = C.IdCorriere
    JOIN Zona Z ON C.IdCorriere = Z.IdCorriere
    WHERE Z.IdZona = p_IdZona 
      AND MONTH(O.DataConsegna) = p_Mese 
      AND YEAR(O.DataConsegna) = p_Anno
      AND O.Stato = 'Consegnato';
END //

-- OPERAZIONE O8: Ricerca storico ordini utente (Utilizza l'indice creato nella Sez. 3.2)
CREATE PROCEDURE SP_StoricoAcquistiCliente(
    IN p_IdCliente INT
)
BEGIN
    SELECT 
        IdOrdine,
        DataCreazione,
        Stato,
        PrezzoTotale
    FROM Ordine
    WHERE IdCliente = p_IdCliente
    ORDER BY DataCreazione DESC;
END //

DELIMITER ;
