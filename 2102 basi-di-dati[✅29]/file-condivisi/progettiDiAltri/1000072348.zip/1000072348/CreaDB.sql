CREATE TABLE Categoria (
    IdCategoria INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descrizione TEXT
);

CREATE TABLE Marchio (
    IdMarchio INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL
);

CREATE TABLE Promozione (
    IdPromo INT PRIMARY KEY,
    Titolo VARCHAR(100) NOT NULL,
    Descrizione TEXT,
    DataInizio DATE NOT NULL,
    DataFine DATE NOT NULL,
    CONSTRAINT chk_date_promo CHECK (DataFine > DataInizio)
);

CREATE TABLE Allergeno (
    IdAllergeno INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descrizione TEXT
);

CREATE TABLE PreferenzaAlimentare (
    IdPreferenza INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descrizione TEXT
);

CREATE TABLE Ricetta (
    IdRicetta INT PRIMARY KEY,
    Nome VARCHAR(255) NOT NULL,
    Descrizione TEXT
);

CREATE TABLE Corriere (
    IdCorriere INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Cellulare VARCHAR(20),
    Capacita INT NOT NULL
);

CREATE TABLE Indirizzo (
    IdIndirizzo INT PRIMARY KEY,
    Via VARCHAR(255) NOT NULL,
    Numero VARCHAR(10) NOT NULL,
    Citta VARCHAR(100) NOT NULL,
    Cap VARCHAR(10) NOT NULL
);

CREATE TABLE Cliente (
    IdCliente INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Email VARCHAR(150) UNIQUE NOT NULL,
    Cellulare VARCHAR(20)
);

-- 2. Tabelle dipendenti (Relazioni 1:N)
CREATE TABLE CartaFedelta (
    IdCarta INT PRIMARY KEY,
    Punti INT DEFAULT 0,
    DataAttivazione DATE NOT NULL,
    Livello VARCHAR(50) NOT NULL,
    IdCliente INT NOT NULL UNIQUE,
    FOREIGN KEY (IdCliente) REFERENCES Cliente(IdCliente)
);

CREATE TABLE Zona (
    IdZona INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descrizione TEXT,
    IdCorriere INT NOT NULL,
    FOREIGN KEY (IdCorriere) REFERENCES Corriere(IdCorriere)
);

CREATE TABLE Prodotto (
    IdProdotto INT PRIMARY KEY,
    Prezzo DECIMAL(10,2) NOT NULL,
    Giacenza INT NOT NULL,
    IsFresco BOOLEAN NOT NULL,
    IdCategoria INT NOT NULL,
    IdMarchio INT NOT NULL,
    IdPromo INT,
    FOREIGN KEY (IdCategoria) REFERENCES Categoria(IdCategoria),
    FOREIGN KEY (IdMarchio) REFERENCES Marchio(IdMarchio),
    FOREIGN KEY (IdPromo) REFERENCES Promozione(IdPromo),
    CONSTRAINT chk_prezzo_prodotto CHECK (Prezzo > 0)
);

CREATE TABLE ListaSalvata (
    IdLista INT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    DataCreazione DATE NOT NULL,
    IdCliente INT NOT NULL,
    FOREIGN KEY (IdCliente) REFERENCES Cliente(IdCliente)
);

CREATE TABLE Ordine (
    IdOrdine INT PRIMARY KEY,
    PrezzoTotale DECIMAL(10,2) NOT NULL,
    DataCreazione DATETIME NOT NULL,
    Stato VARCHAR(50) NOT NULL,
    Tipo VARCHAR(50) NOT NULL,
    DataConsegna DATETIME NOT NULL,
    FasciaOraria VARCHAR(50) NOT NULL,
    IdCliente INT NOT NULL,
    IdIndirizzo INT NOT NULL,
    IdCorriere INT NOT NULL,
    FOREIGN KEY (IdCliente) REFERENCES Cliente(IdCliente),
    FOREIGN KEY (IdIndirizzo) REFERENCES Indirizzo(IdIndirizzo),
    FOREIGN KEY (IdCorriere) REFERENCES Corriere(IdCorriere),
    CONSTRAINT chk_prezzo_ordine CHECK (PrezzoTotale > 0),
    CONSTRAINT chk_date_ordine CHECK (DataConsegna >= DataCreazione)
);

CREATE TABLE BorsaTermica (
    IdBorsa INT PRIMARY KEY,
    Capacita INT NOT NULL,
    Stato VARCHAR(50) NOT NULL,
    IdOrdine INT NOT NULL,
    FOREIGN KEY (IdOrdine) REFERENCES Ordine(IdOrdine)
);

-- 3. Tabelle di Legame (Relazioni N:M)
CREATE TABLE ProdottoAllergeno (
    IdProdotto INT NOT NULL,
    IdAllergeno INT NOT NULL,
    PRIMARY KEY (IdProdotto, IdAllergeno),
    FOREIGN KEY (IdProdotto) REFERENCES Prodotto(IdProdotto),
    FOREIGN KEY (IdAllergeno) REFERENCES Allergeno(IdAllergeno)
);

CREATE TABLE RicettaProdotto (
    IdRicetta INT NOT NULL,
    IdProdotto INT NOT NULL,
    Quantita DECIMAL(10,2) NOT NULL,
    UnitaMisura VARCHAR(50) NOT NULL,
    PRIMARY KEY (IdRicetta, IdProdotto),
    FOREIGN KEY (IdRicetta) REFERENCES Ricetta(IdRicetta),
    FOREIGN KEY (IdProdotto) REFERENCES Prodotto(IdProdotto),
    CONSTRAINT chk_quantita_ricetta CHECK (Quantita > 0)
);

CREATE TABLE ClientePreferenza (
    IdCliente INT NOT NULL,
    IdPreferenza INT NOT NULL,
    PRIMARY KEY (IdCliente, IdPreferenza),
    FOREIGN KEY (IdCliente) REFERENCES Cliente(IdCliente),
    FOREIGN KEY (IdPreferenza) REFERENCES PreferenzaAlimentare(IdPreferenza)
);

CREATE TABLE ClienteIndirizzo (
    IdCliente INT NOT NULL,
    IdIndirizzo INT NOT NULL,
    PRIMARY KEY (IdCliente, IdIndirizzo),
    FOREIGN KEY (IdCliente) REFERENCES Cliente(IdCliente),
    FOREIGN KEY (IdIndirizzo) REFERENCES Indirizzo(IdIndirizzo)
);

CREATE TABLE ListaProdotto (
    IdLista INT NOT NULL,
    IdProdotto INT NOT NULL,
    Quantita INT NOT NULL,
    PRIMARY KEY (IdLista, IdProdotto),
    FOREIGN KEY (IdLista) REFERENCES ListaSalvata(IdLista),
    FOREIGN KEY (IdProdotto) REFERENCES Prodotto(IdProdotto),
    CONSTRAINT chk_quantita_lista CHECK (Quantita > 0)
);

CREATE TABLE OrdineProdotto (
    IdOrdine INT NOT NULL,
    IdProdotto INT NOT NULL,
    Quantita INT NOT NULL,
    PrezzoAcquisto DECIMAL(10,2) NOT NULL,
    IdSostituto INT,
    DataAggiunta DATETIME NOT NULL,
    PRIMARY KEY (IdOrdine, IdProdotto),
    FOREIGN KEY (IdOrdine) REFERENCES Ordine(IdOrdine),
    FOREIGN KEY (IdProdotto) REFERENCES Prodotto(IdProdotto),
    FOREIGN KEY (IdSostituto) REFERENCES Prodotto(IdProdotto),
    CONSTRAINT chk_quantita_ordine CHECK (Quantita > 0)
);
